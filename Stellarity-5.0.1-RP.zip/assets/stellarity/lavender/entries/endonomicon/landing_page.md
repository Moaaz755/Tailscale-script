```json
{
  "title": "Endonomicon",
  "icon": "minecraft:ender_pearl"
}
```

This is the landing page of the Endonomicon. UwU
