```json
{
  "title": "Exploration",
  "icon": "minecraft:purpur_block"
}
```
The End has many structures that are waiting for you to discover their secrets. Sort of, because they are all quite hostile.
